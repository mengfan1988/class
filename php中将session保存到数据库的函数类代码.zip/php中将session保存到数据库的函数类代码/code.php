<?php
//
// 'sessions' table schema
// create table sessions (
//   session_id char(32) not null,
//   session_data text not null,
//   session_expiration int(11) unsigned not null,
//   primary key (session_id));
//

include_once 'DB.php';

// Global Variables
$dbh = NULL;

function on_session_start ($save_path, $session_name) {
    global $dbh;
    $dbh = DB::connect('mysql://user:secret@localhost/SITE_SESSIONS',
      true);

    if (DB::isError($dbh)) {
        die(sprintf('Error [%d]: %s',
          $dbh->getCode(), $dbh->getMessage()));
    }
}

function on_session_end ()
{
    // Nothing needs to be done in this function
    // since we used persistent connection.
}

function on_session_read ($key)
{
    global $dbh;

    $stmt = "select session_data from sessions";
    $stmt .= " where session_id = '$key'";
    $stmt .= " and session_expiration > now()";

    $sth = $dbh->query($sth);
    $row = $sth->fetchRow(DB_FETCHMODE_ASSOC);
    return $row['session_data'];
}

function on_session_write ($key, $val)
{
    global $dbh;

    $val = addslashes($val);

    $insert_stmt = "insert into sessions values('$key', '$val', now() + 3600)";
    $update_stmt = "update sessions set session_data = '$val', ";
    $update_stmt .= "session_expiration = now() + 3600 ";
    $update_stmt .= "where session_id = '$key'";

    // First we try to insert, if that doesn't succeed, it means
    // session is already in the table and we try to update
    if (DB::isError($dbh->query($insert_stmt)))
        $dbh->query($update_stmt);
}

function on_session_destroy ($key)
{
    global $dbh;

    $stmt = "delete from sessions where session_id = '$key'";
    $dbh->query($stmt);
}

function on_session_gc ($max_lifetime)
{
    global $dbh;

    // In this example, we don't use $max_lifetime parameter
    // We simply delete all sessions that have expired
    $stmt = "delete from sessions where session_expiration < now()";
    $dbh->query($stmt);
}

session_start ();

// Register the $counter variable as part
// of the session
session_register ("counter");

// Set the save handlers
session_set_save_handler ("on_session_start",   "on_session_end",
  "on_session_read",    "on_session_write",
  "on_session_destroy", "on_session_gc");

// Let's see what it does
$counter++;
print $counter;
session_destroy();
?>
