<?php
/**
 * 取得下周一时的结算区间
 */
class Project_View_Helper_TaskNotice
{

    /**
     * @return string
     */
    public function TaskNotice() {
        $nextMonday = $this->getNextMonday();
        $lastMonday = $this->getLastMonday();
        $lastSunday = $this->getLastSunday();
        $notice = '下周一（'. $nextMonday .'）结算'. $lastMonday .'至'. $lastSunday .'的款项。（如遇节假日顺延）';
        return $notice;
    }

    /**
     * 取得下个周一
     * @internal param $time
     */
    private function getNextMonday()
    {
        return date('m月d日',strtotime('+1 week last monday'));
    }

    /**
     * 取得上个周一
     * @return string
     */
    private function getLastMonday()
    {
        if (date('l',time()) == 'Monday') return date('m月d日',strtotime('last monday'));

        return date('m月d日',strtotime('-1 week last monday'));
    }

    /**
     * 取得上个周日
     * @return string
     */
    private function getLastSunday()
    {
        return date('m月d日',strtotime('last sunday'));
    }
}

