<?php
header('Content-Type:text/html;charset=utf-8');

/**
 * 一个用于抓去图片的类
 */
class download_image {
    public $_save_path = NULL; //图片保存路劲
    public $_limit_size = NULL; //图片限制大小
    public static $_img_url_old = array();  //存储已抓取过的图片链接地址
    public static $_a_page_url = array();    //存储抓取过的页面
    public function __construct( $_save_path, $_limit_size) {
        $this->_save_path = $_save_path;
        $this->_limit_size = $_limit_size;
    }

    public function get_all_page_image( $site_url ) {
        if ( $site_url == '' ) {
            return false;
        }
        if ( ! in_array( $site_url, self::$_a_page_url ) ) {  //判断当前页面是否抓取过
            self::$_a_page_url[] = $site_url;   //将超链接存入静态数组中
        } else {
            return;     //若抓取过则跳出
        }
        $this->download_the_page_image( $site_url );
        $content = @file_get_contents($site_url);
        $a_page_url = "|<a[^>]+href=['\\" ]?([^ '\\"?]+)['\\" >]|U";
        $all_url = array();
        preg_match_all( $a_page_url, $content, $all_url, PREG_SET_ORDER );
        if ( $all_url != NULL ) {
            foreach( $all_url as $key => $val ) {
                /**
                 * 静态化超链接，防止进入死循环
                 * 出去当前页面链接表示方式（'','#','/'）
                 */
                if ( trim($val[1]) != '' && ! in_array( $val[1], self::$_a_page_url ) && ! in_array( $val[1], array('#','/',$site_url) ) ) {
                    self::$_a_page_url[] = $val[1];   //将符合要求的超链接写入静态数组中
                }
            }
        }
        if ( self::$_a_page_url != NULL ) {
            foreach( self::$_a_page_url as $keys => $vals ) {
                if ( strpos( $vals, 'http://' ) === false ) { //超链接不包含http://时，不能直接访问
                    // 当图片链接地址为相对地址是重新拼凑地址
                    $a_domain_url = substr( $site_url, 0, strpos( $site_url, '/',8 ) + 1 );
                    $a_img_url = $a_domain_url.$vals;
                }
                //递归调用，访问每一个超链接页面
                $this->get_all_page_image( $a_img_url );
            }
        }
    }

    /**
     * 下载当前页面下的所有图片链接
     * @param $site_url   <页面地址>
     */
    public function download_the_page_image( $site_url ) {
        // 获取当前链接地址页面的所有内容
        $img_pattern = NULL;
        $content = @file_get_contents( $site_url );
        $img_pattern = "|<img[^>]+src=['\\" ]?([^ '\\"?]+)['\\" >]|U";
        //全局匹配所有的<img >中的图片链接
        $img_out = array();
        preg_match_all( $img_pattern, $content, $img_out, PREG_SET_ORDER );
        echo '<h1>'. $site_url . '共找到' . count($img_out) . '张图片</h1>';
        //print_r($img_out[1]);
        foreach( $img_out as $key => $val ) {
            //echo htmlspecialchars($val[1]).'<br />';
            $this->save_one_image( $site_url, $val[1]);
        }

    }

    public function save_one_image( $site_url, $img_url ) {
        if ( strpos( $img_url, 'http://' ) === false ) {
            // 当图片链接地址为相对地址是重新拼凑地址
            $domain_url = substr( $site_url, 0, strpos( $site_url, '/',8 ) + 1 );
            $img_url = $domain_url.$img_url;
        }
        $pic_name = basename( $img_url ); //获取图片名称

        if ( in_array( $img_url, self::$_img_url_old ) ) {
            echo $img_url .'<span style="color:red;margin-left:50px">该图片已经抓取过!</span><br/>';
            return;
        }
        //获取图片内容，并写入一个字符串
        $img_data = @file_get_contents( $img_url );
        if ( strlen($img_data) < $this->_limit_size ) { //图片大小在限制范围内
            $img_boo = @file_put_contents( $this->_save_path.md5(microtime()).$pic_name, $img_data );
            if ( $img_boo ) {
                echo $img_url .'<span style="color:green;margin-left:50px;">图片保存成功！</span><br/>';
                self::$_img_url_old[] = $img_url;
            } else {
                echo $img_url .'<span style="color:red;margin-left:50px;">图片保存失败！</span><br />';
            }
        } else {
            echo $img_url .'<span style="color:red;margin-left:50px;">图片大小在限制范围之外！</span><br />';
        }
    }
}
set_time_limit(0);
$download_images = new download_image('surces_Img/',1024*1024*100);
$download_images->get_all_page_image('http://www.php.cn/');
?>